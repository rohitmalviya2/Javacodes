import java.util.*;
public class Starpattern3 {
    public static void main(String[] args) {
         int i,j,k,rows;
         Scanner sc = new Scanner(System.in);
         rows = sc.nextInt();
         for(i=1;i<=rows;i++){
            for(j=rows;j>i;j--){
                System.out.print(" ");
            }
            for(k=0;k<2*i-1;k++){
            System.out.print("*");
         }
         System.out.println();

    }
    
}
}
