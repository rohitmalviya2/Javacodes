import java.util.*;
public class Vowelswithspecialcharacter {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        String s1=sc.nextLine();
        for(int i=0;i<s1.length();i++){
            char c=s1.charAt(i);
            {
                if(c=='A'||c=='E'||c=='I'||c=='O'||c=='U'){
                    String f=s1.substring(0,i);
                    String l=s1.substring(i+1);
                    s1=f+"$"+l;


                }
            }
        }
             System.out.println(s1);

    }
    
}
