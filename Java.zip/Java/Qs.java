import java.util.*;
class Qs{
   static int partition(int a[],int lb,int ub){
       int  pivot=a[lb];
        int start=lb;
        int end=ub;
        while(start<end){
            while(a[start]<=pivot){
                start++;
            }
            while(a[end]>pivot){
                end--;
            }
            if(start<end){
                int temp=a[start];
                a[start]=a[end];
                a[end]=temp;
            }
        }
        int temp2=a[lb];
        a[lb]=a[end];
        a[end]=temp2;
        return end;
 }
 static void Quicksort(int A[],int lb,int ub) {
    if(lb<ub){
        int loc = partition(A,lb,ub);
        Quicksort(A,lb,loc-1);
        Quicksort(A,loc+1,ub);
     }
}
  
    public static void main(String[] args) {
        int a[]={13,4,72,2,23,3};
        int n = a.length;
        B.Quicksort(a,0,n-1);
        System.out.println(Arrays.toString(a));


    }
}