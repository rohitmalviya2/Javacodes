import java.util.Scanner;

public class Power {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int base = sc.nextInt();
        int power = sc.nextInt();
        int ans=1;
        while(power>0){
           ans=base*ans;
          power--;
        }
        System.out.println(ans);

    }
    
}
