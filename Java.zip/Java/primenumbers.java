import java.util.*;
public class primenumbers {
    public static void main(String[] args) {
           int m=0;int flag=0;
           Scanner sc = new Scanner(System.in);
          int n=sc.nextInt();
           m=n/2;
           if(n==1||n==0){
            System.out.println("Not Prime");
           }
           else{
            for(int i=2;i<=m;i++){
                if(n%i==0){
                    System.out.println("Not prime");
                    flag=1;
                    break;
                }
            }
            if(flag==0){
                System.out.println("Prime");
            }
           }

    }
    
}
