import java.util.Scanner;

public class Max{
    public static void main(String[] args) {
        int arr[]=new int[6];
        
        Scanner sc = new Scanner(System.in);
        for(int i=0;i<arr.length;i++){
        arr[i]=sc.nextInt();
        }
        int largest=arr[0];
        int smallest=arr[0];
        for(int i=0;i<arr.length;i++){
            if(arr[i]>largest){
                largest=arr[i];
            }
        }
       
        for(int i=0;i<arr.length;i++){
            if(arr[i]<smallest){
                smallest=arr[i];
            }
        }
        System.out.println("largest " +largest);
        System.out.println("smallest " +smallest);
    }
}