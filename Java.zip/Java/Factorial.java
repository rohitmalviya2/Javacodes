public class Factorial {
    public static void main(String[] args) {
        int number=6; int value=1;
        for(int i=number;i>0;i--){
            value=value*i;

        }
        System.out.print(value);
    }
    
}
