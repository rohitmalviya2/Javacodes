import java.util.*;
class Countconsonent{
    public static void main(String[] args) {
        int vowels=0;
        int consonents=0;
        Scanner sc= new Scanner(System.in);
        String reference="AaEeIiOoUu";
        String ref=sc.nextLine();
        for(int i=0;i<ref.length();i++){
            if(ref.charAt(i)>='A'&&ref.charAt(i)<='Z'||ref.charAt(i)>='a'&&ref.charAt(i)<='z'){
                if(reference.indexOf(ref.charAt(i))!=-1){
                    vowels++;
                }
                else{
                    consonents++;
                }
            }


                         }
                         System.out.println("vowels"+vowels);
                         System.out.println("consonents"+consonents);
        }
    }

        
    
