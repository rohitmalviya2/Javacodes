import java.util.*;
public class Starpattern1 {
    public static void main(String[] args) {
     int rows,i,j;
     Scanner sc= new Scanner(System.in);
     System.out.println("Enter the rows");
     rows=sc.nextInt();
     for( i=0;i<rows;i++)
     {
        for(j=0;j<=i;j++)
        {
            System.out.print("*");
        }
        System.out.println();
     }
    
}
}
