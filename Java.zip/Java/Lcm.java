import java.util.*;
public class Lcm {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int i=0;
        int x=sc.nextInt();
        int y=sc.nextInt();
        int a=x>y?x:y;
        for(i=a;i<x*y;i=i+a){
            if(i%x==0&&i%y==0){
                break;
            }
            
            

        }
         
        System.out.println(i);
    }
    
}
