import java.util.*;
public class Anagram {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s1=sc.nextLine();
        String s2=sc.nextLine();
        
        char a[]= s1.toCharArray();
        char b[]= s2.toCharArray();
        int flag=0;
        if(a.length!=b.length){
            System.out.println("NOt Anagram");
            
              
             }
             
          
    else{
            Arrays.sort(a);
            Arrays.sort(b);
            for(int i=0;i<a.length;i++){
                if(a[i]!=b[i]){
                System.out.println("Not Anagram");
                flag=1;
                break;
                
            }
            
    }
    if (flag==0){
        System.out.println("Anagram");
    }
}
}
}
    

