import java.util.Scanner;

public class Binarytodecimal {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int binarynumber=sc.nextInt();
        int decimalnumber=0;
        int n=0;
        while(binarynumber>0){
            int temp=binarynumber%10;
            decimalnumber+=temp*Math.pow(2,n);
            binarynumber=binarynumber/10;
            n++;
        }
        System.out.println(decimalnumber);
    }
    
}
