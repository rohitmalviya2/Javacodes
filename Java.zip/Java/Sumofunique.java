import java.util.*;
public class Sumofunique {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n=sc.nextInt();
        int ar[]=new int[n];
        for(int i=0;i<n;i++){
            ar[i]=sc.nextInt();
        }
        Arrays.sort(ar);
        int sum=ar[0];
        for(int k=0;k<n-1;k++){
            if(ar[k]!=ar[k+1]){
                sum=sum+ar[k+1];
            }
        }
        System.out.println(sum);
         
    }
    
}
