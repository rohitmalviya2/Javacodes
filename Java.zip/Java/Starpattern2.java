import java.util.*;
public class Starpattern2 {
    public static void main(String[] args) {
         int rows,i,j,k;
         System.out.println("Enter the rows");
         Scanner sc = new Scanner(System.in);
         rows=sc.nextInt();
         for(i=0;i<rows;i++){
            for(j=rows;j>i;j--){
                System.out.print(" ");      
            }
                for(k=0;k<=i;k++){
                    System.out.print("*");
                }
                     
            System.out.println();
         }
    }
    
}
