import java.util.*;

public class Armstrong {
    public static void main(String[] args) {
        Scanner sc =  new Scanner(System.in);
        int n=sc.nextInt();
        int temp=n;
        int digits=0;
        while(temp>0){
            temp=temp/10;
            digits++;
        }
        temp=n;
        int sum=0;
        while(temp>0){
           int last =temp%10;
           
            sum+=Math.pow(last,digits);
            temp=temp/10;
        }
        if(n==sum){
            System.out.println("Armstrong");

        }
        else{
            System.out.println("Not armstrong");
            }
         
    }
    
}

