import java.util.*;
class Alphabettringle{
 public static void main(String[] args){
    int i,j,rows=5,alphabet=97;
    for( i=0;i<rows;i++){
        for( j=0;j<=i;j++){
            System.out.print((char)(alphabet));
        }
        alphabet++;
        System.out.println();
    }
 }
}